const db = require('./config/db');

db.connect((err) => {
  if (err) {
    console.error("❌ MySQL Connection Error:", err.message);
    process.exit(1);
  } else {
    console.log("✔ Connected to MySQL");
    db.end();
    process.exit(0);
  }
});
